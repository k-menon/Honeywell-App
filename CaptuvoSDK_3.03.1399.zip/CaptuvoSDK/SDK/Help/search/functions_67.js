var searchData=
[
  ['getcaptuvofirmwarerevision',['getCaptuvoFirmwareRevision',['../interface_captuvo.html#ac4893427f774d5ed2d8f8c2114c4357c',1,'Captuvo']]],
  ['getcaptuvohardwarerevision',['getCaptuvoHardwareRevision',['../interface_captuvo.html#aff4df490a002bec07126a5f124cd2d8a',1,'Captuvo']]],
  ['getcaptuvomanufacturer',['getCaptuvoManufacturer',['../interface_captuvo.html#addb6b5fca35d006df056fa89f7fd30ef',1,'Captuvo']]],
  ['getcaptuvomodelnumber',['getCaptuvoModelNumber',['../interface_captuvo.html#adb616c110d9f7d04287671d98b73abe5',1,'Captuvo']]],
  ['getcaptuvoname',['getCaptuvoName',['../interface_captuvo.html#af015b1b39f299bd941e713b813128021',1,'Captuvo']]],
  ['getcaptuvoserialnumber',['getCaptuvoSerialNumber',['../interface_captuvo.html#a44928f59e1680dc40e7185546c62de48',1,'Captuvo']]],
  ['getchargestatus',['getChargeStatus',['../interface_captuvo.html#a3f9e10f8b37268d9e59c54affa3e56ad',1,'Captuvo']]],
  ['getsdkbuildnumber',['getSDKbuildNumber',['../interface_captuvo.html#aa3d70325766fb1e36403e0ce86bf5aff',1,'Captuvo']]],
  ['getsdkfullversion',['getSDKfullVersion',['../interface_captuvo.html#a306abf49b6b7f225ebd212215af7a3fe',1,'Captuvo']]],
  ['getsdkshortversion',['getSDKshortVersion',['../interface_captuvo.html#ad84542384516fcd54ee7bc07c6373fc6',1,'Captuvo']]]
];
