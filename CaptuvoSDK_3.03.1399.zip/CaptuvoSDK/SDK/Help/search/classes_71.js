var searchData=
[
  ['qrcode',['QRCode',['../interface_q_r_code.html',1,'']]]
];
