var searchData=
[
  ['qrcode',['QRCode',['../interface_q_r_code.html',1,'']]],
  ['querybatteryauthstatus',['queryBatteryAuthStatus',['../category_captuvo_07_private_a_p_i_08.html#a0102c6f55573c44c6bc3a5a64f68947b',1,'Captuvo(PrivateAPI)::queryBatteryAuthStatus()'],['../interface_captuvo.html#a0102c6f55573c44c6bc3a5a64f68947b',1,'Captuvo::queryBatteryAuthStatus()']]],
  ['querybatterychargingstatus',['queryBatteryChargingStatus',['../category_captuvo_07_private_a_p_i_08.html#a6d0858fbaede0bc8ed7e4a49110dbf7c',1,'Captuvo(PrivateAPI)::queryBatteryChargingStatus()'],['../interface_captuvo.html#a6d0858fbaede0bc8ed7e4a49110dbf7c',1,'Captuvo::queryBatteryChargingStatus()']]],
  ['querybatterytype',['queryBatteryType',['../category_captuvo_07_private_a_p_i_08.html#afea00b9161adc2594663666d5ade0d6c',1,'Captuvo(PrivateAPI)::queryBatteryType()'],['../interface_captuvo.html#afea00b9161adc2594663666d5ade0d6c',1,'Captuvo::queryBatteryType()']]],
  ['querymsrhidmode',['queryMSRHIDMode',['../interface_captuvo.html#a30e54614269feee8c9955220f4313542',1,'Captuvo']]]
];
