var searchData=
[
  ['lockhidmode',['lockHIDMode',['../interface_captuvo.html#a0b8dfad14a3d2d089fde709a9cb605e7',1,'Captuvo']]]
];
