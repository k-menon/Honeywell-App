var searchData=
[
  ['weakzeroingdelegatenode',['WeakZeroingDelegateNode',['../interface_weak_zeroing_delegate_node.html',1,'']]]
];
