//
//  SecondViewController.h
//  CaptuvoBasicSimples
//
//  Created by zhou shadow on 4/20/15.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "core/coreCaptuvo.h"
@interface MSRViewController : UIViewController
@property(nonatomic,strong) IBOutlet UILabel *swipemsrlbl;

@end

