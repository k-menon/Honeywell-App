//
//  ViewController.m
//  OCRSample
//
//  Created by zhou shadow on 7/2/15.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import "OCRViewController.h"
#import "OCRMode.h"
#import "ocrCodeObject.h"
@interface OCRViewController ()
{
    NSMutableArray *scanOCRcodeArray ;
    ocrCodeObject *ocrOjbect ;
}
@end

@implementation OCRViewController
@synthesize label,tableview,appVersionlabel ;
- (void)viewDidLoad {
    [super viewDidLoad];
    scanOCRcodeArray = [[NSMutableArray alloc] init] ;

    [[Captuvo sharedCaptuvoDevice] addCaptuvoDelegate:self] ;
    self.appVersionlabel.backgroundColor = [UIColor clearColor] ;
    self.appVersionlabel.font = [UIFont systemFontOfSize:8] ;
    self.appVersionlabel.numberOfLines = 0 ;
    self.appVersionlabel.lineBreakMode = NSLineBreakByCharWrapping ;
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
    self.appVersionlabel.text =[NSString stringWithFormat:@"App Version:%@\nSDK Version:%@",version,[[Captuvo sharedCaptuvoDevice] getSDKshortVersion]]  ;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)decoderReady
{
    
    [[OCRMode sharedOCRMode] initOCRConfigure];
    
}


- (void)decoderPassThroughReturnData:(NSData *)data
{
    [[OCRMode sharedOCRMode] ParseOcrLicenseinThroughData:data];
    
    if ([OCRMode sharedOCRMode].ocrLicenseStatus == LICENSED) {
        NSString *content = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding] ;
        content = [content stringByReplacingOccurrencesOfString:@"\n\r" withString:@"\n"] ;
        self.label.text =[NSString stringWithFormat:@"OCR Plugin Info:\n%@",content]  ;
    }
}
- (void)decoderDataReceived:(NSString *)data
{
    BOOL Notexist = YES ;
    for (ocrCodeObject *obj in scanOCRcodeArray) {
        if ([data isEqualToString:obj.barcode]) {
            //if the same barcode scanned will added the count
            obj.counter ++ ;
            Notexist = NO ;
            break ;
        }else{
            Notexist = YES ;
        }
    }
    if (Notexist) {
        ocrCodeObject *newobj = [[ocrCodeObject alloc] init] ;
        newobj.barcode = data ;
        newobj.counter = 1 ;
        [scanOCRcodeArray addObject:newobj] ;
    }
    [self.tableview reloadData] ;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"Scan OCR list" ;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [scanOCRcodeArray count] ;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    // Configure the cell...
    ocrCodeObject *obj = [scanOCRcodeArray objectAtIndex:indexPath.row] ;
    cell.textLabel.text = [NSString stringWithFormat:@"@%ld\t %@",(long)obj.counter,obj.barcode] ;
    cell.textLabel.numberOfLines = 0 ;
    cell.textLabel.font = [UIFont systemFontOfSize:13] ;
    
    return cell ;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder] ;
    
    NSString *textString = textField.text ;
    
    if ([textString length]==0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"OCR Configuration reminder" message:@"OCR customer templates setting need fill data formate like '1 3 5 5 5 5 5 5 5 5'" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil]  ;
        [alert show] ;
        return YES;
    }
    self.label.text = @"OCR Plugin Info:" ;
    textString = [textString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] ;
    const unsigned char header[] = {0x16,0x4d,0x0d,'O','C','R','D','F','T',';', 'O','C','R','E','N','A','3',';','O','C','R','T','M','P','"'} ;
    NSMutableData* data = [[NSMutableData alloc] initWithBytes:&header length:sizeof(header)];
    NSInteger length = [textString length] ;
    for (int i = 0 ; i < length ; i++) {
        /*
         any customer template should support.
         */
        NSString *ocharacter = [textString substringWithRange:NSMakeRange(i, 1)] ;
        [data appendData:[ocharacter dataUsingEncoding:NSASCIIStringEncoding]] ;
    }
    const unsigned char tail[] = {'"','!'} ;
    [data appendBytes:&tail length:sizeof(tail)] ;
    
    /*The command result should be as: 0x16, 0x4d,0x0d, OCRTMP"array".
     array should be 13555555....0, should check the OCR UG Control Codes Chart to understand the mean.
     */
    NSLog(@"%@",[[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding]) ;
    [[Captuvo sharedCaptuvoDevice] decoderPassThrough:data expectingReturnData:YES] ;
    
    return YES ;
}

@end
