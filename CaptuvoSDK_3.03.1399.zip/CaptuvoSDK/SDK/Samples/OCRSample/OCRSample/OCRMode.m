//
//  NSObject+OCRMode.m
//  OCRDemo
//
//  Created by Chris on 15-3-13.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import "OCRMode.h"

@interface OCRMode()

- (id)init;
- (void)checkORClicense;


@end

@implementation OCRMode

@synthesize ocrLicenseStatus;

static OCRMode *sharedOCRMode = nil;

- (id)init {
    
    self = [super init];
    if (self) {
        
        self.ocrLicenseStatus = UNLICENSED ;
        
    }
    return self;
}

+(OCRMode*)sharedOCRMode{
    if (nil != sharedOCRMode) {
        return sharedOCRMode;
    }
    static dispatch_once_t pred;        // Lock
    dispatch_once(&pred, ^{             // This code is called at most once per app
        sharedOCRMode = [[OCRMode alloc] init];
        
    });
    return sharedOCRMode;
}

- (void)ParseOcrLicenseinThroughData:(NSData *)data
{
    
    NSString *passthroughdata = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding] ;
    
    //if the license have been verified.
    NSString *licenseheader = @"ACTSTA";
    NSString *enableheader = @"OCR" ;
    NSRange hRange = NSMakeRange(0, 0) ;
    NSRange eRange = NSMakeRange(0, 0) ;
    
    NSUInteger OcrLicenselength = [licenseheader length] + [enableheader length];
    
    if ([passthroughdata length]> OcrLicenselength) {
        hRange = [passthroughdata rangeOfString:licenseheader] ;
        
        if ([passthroughdata length]>[enableheader length]) {
            eRange =[passthroughdata rangeOfString:enableheader] ;
        }
    }
    
    if ((hRange.location!=NSNotFound)&& (hRange.length > 0)) {
        
         self.ocrLicenseStatus  = UNLICENSED ;
        
        if((eRange.location!= NSNotFound) && (eRange.length > 0))
        {
            
            NSString *enable = nil;
            if ([passthroughdata length]>[enableheader length]+3+7) {
                
                enable = [passthroughdata substringWithRange:NSMakeRange(eRange.location+ eRange.length+3, 7)] ;
                
            }
            if(enable != nil)
            {
                NSString *strEnable = @"Enable";
               if (([enable rangeOfString:@"Enabled"].location!=NSNotFound)&& ([enable length] > [strEnable length]) ){
                
                
                //Enabled
                self.ocrLicenseStatus  = LICENSED;
              
                
               }
            }
        }
        if([OCRMode sharedOCRMode].ocrLicenseStatus  == UNLICENSED)
        {
            //Disable
            UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"OCR Disable" message:@"This Captuvo' OCR is disable, please check whether the plugin or license is existing!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] ;
            [alertview show] ;
        }

    }
}
- (void)initOCRConfigure
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //if want OCR working must disable all symbology.
        [[Captuvo sharedCaptuvoDevice] disableAllSymbologiesPersistSetting:NO] ;
    });
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        
        //OCRDFT. OCRENA1.
        const unsigned char msg[] = {0x16,0x4d,0x0d,'O','C','R','D','F','T',';',
            'O','C','R','E','N','A','3','!'} ;
        NSMutableData* data = [[NSMutableData alloc] initWithBytes:&msg length:sizeof(msg)];
        
        
        [[Captuvo sharedCaptuvoDevice] decoderPassThrough:data expectingReturnData:YES] ;
        
    });
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self checkORClicense] ;
    });
    

}

- (void)checkORClicense
{   // send command to request the response then inditify whether has ocr license.
    const unsigned char msg[] = {0x16,0x4d,0x0d,'A','C','T','S','T','A','!'} ;
    NSMutableData* data = [[NSMutableData alloc] initWithBytes:&msg length:sizeof(msg)];
    [[Captuvo sharedCaptuvoDevice] decoderPassThrough:data expectingReturnData:YES] ;
}

@end
