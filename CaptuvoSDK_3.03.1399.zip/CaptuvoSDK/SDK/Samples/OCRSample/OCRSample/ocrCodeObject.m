//
//  ocrCodeObject.m
//  OCRDemo
//
//  Created by zhou shadow on 11/28/14.
//  Copyright (c) 2014 Honeywell Inc. All rights reserved.
//

#import "ocrCodeObject.h"

@implementation ocrCodeObject
@synthesize  barcode = _barcode ;
@synthesize  counter = _counter ;
@synthesize  other  = _other ;
- (id)init{
    self = [super init] ;
    if (self!=nil) {
        //initialize this object class members.
    }
    return self;
}
@end
