//
//  AppDelegate.h
//  OCRSample
//
//  Created by zhou shadow on 7/2/15.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

