//
//  ocrCodeObject.h
//  OCRDemo
//
//  Created by zhou shadow on 11/28/14.
//  Copyright (c) 2014 Honeywell Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ocrCodeObject : NSObject
@property (nonatomic,strong) NSString *barcode ;
@property (nonatomic,assign) NSInteger counter ;
@property (nonatomic,strong) NSString *other ;
@end
