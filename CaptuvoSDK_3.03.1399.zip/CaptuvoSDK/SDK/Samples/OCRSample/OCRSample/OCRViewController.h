//
//  ViewController.h
//  OCRSample
//
//  Created by zhou shadow on 7/2/15.
//  Copyright (c) 2015 Honeywell Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Captuvo.h"
@interface OCRViewController : UIViewController<CaptuvoEventsProtocol,UITableViewDataSource,UITableViewDelegate,
UITextFieldDelegate>
@property (nonatomic,strong) IBOutlet UILabel *label ;
@property (nonatomic,strong) IBOutlet UILabel *appVersionlabel ;
@property (nonatomic,strong) IBOutlet UITableView *tableview ;
@end

