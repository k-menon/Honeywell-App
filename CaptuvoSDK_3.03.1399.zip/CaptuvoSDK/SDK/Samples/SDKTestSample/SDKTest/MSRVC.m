/*======================================================================
 
 UNLESS OTHERWISE AGREED TO IN A SIGNED WRITING BY HONEYWELL INTERNATIONAL INC
 (“HONEYWELL”) AND THE USER OF THIS CODE, THIS CODE AND INFORMATION IS PROVIDED
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
 FOR A PARTICULAR PURPOSE.
 
 COPYRIGHT (C) 2008 HONEYWELL INTERNATIONAL INC.
 
 THIS SOFTWARE IS PROTECTED BY COPYRIGHT LAWS OF THE UNITED STATES OF
 AMERICA AND OF FOREIGN COUNTRIES. THIS SOFTWARE IS FURNISHED UNDER A
 LICENSE AND/OR A NONDISCLOSURE AGREEMENT AND MAY BE USED IN ACCORDANCE
 WITH THE TERMS OF THOSE AGREEMENTS. UNAUTHORIZED REPRODUCTION,  DUPLICATION
 OR DISTRIBUTION OF THIS SOFTWARE, OR ANY PORTION OF IT  WILL BE PROSECUTED
 TO THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW.
 
 ======================================================================*/
//
//  MSRVC.m
//  SDKTest
//

#import "MSRVC.h"
#import "MSRTools.h"

@interface MSRVC ()
{
    NSInteger swipeSuccessCount ;
}
@end

@implementation MSRVC

@synthesize msrData = _msrData;
@synthesize msrRawData = _msrRawData;
@synthesize switchbtn = _switchbtn ;
@synthesize msrHIDModelbl = _msrHIDModelbl;
@synthesize swipesuccessCountlbl = _swipesuccessCountlbl ;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
   self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
   if (self) {
      self.title = @"MSR Test";
   }
   return self;
}

- (void)viewDidLoad
{
   [super viewDidLoad];
   // Do any additional setup after loading the view from its nib.
    swipeSuccessCount = 0 ;
}

- (void)viewDidUnload
{
   [self setMsrRawData:nil];
   [super viewDidUnload];
   // Release any retained subviews of the main view.
   // e.g. self.myOutlet = nil;
}

-(void)viewWillAppear:(BOOL)animated{
    
    
    [[Captuvo sharedCaptuvoDevice] addCaptuvoDelegate:self];
    [[Captuvo sharedCaptuvoDevice] startMSRHardware];
    
    [[Captuvo sharedCaptuvoDevice] queryMSRHIDMode] ;    
    
}

-(void)viewDidDisappear:(BOOL)animated
{
    [[Captuvo sharedCaptuvoDevice] removeCaptuvoDelegate:self];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
   return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)startMSR:(id)sender {
   ProtocolConnectionStatus status = [[Captuvo sharedCaptuvoDevice]startMSRHardware];
   if (status != ProtocolConnectionStatusConnected) {
      NSLog(@"Problem connection to protocol");
   }
}

- (IBAction)stopMSR:(id)sender {
   [[Captuvo sharedCaptuvoDevice]stopMSRHardware];
}

- (IBAction)allTracksButton:(id)sender {
   [[Captuvo sharedCaptuvoDevice]setMSRTrackSelection:TrackSelectionAnyTrack];
}

- (IBAction)track1Button:(id)sender {
   [[Captuvo sharedCaptuvoDevice]setMSRTrackSelection:TrackSelectionRequire1];
}

- (IBAction)track2Button:(id)sender {
   [[Captuvo sharedCaptuvoDevice]setMSRTrackSelection:TrackSelectionRequire2];
}

- (IBAction)track3Button:(id)sender {
   [[Captuvo sharedCaptuvoDevice]setMSRTrackSelection:TrackSelectionRequire1and2];
}

- (IBAction)trackcommButton:(id)sender
{
    UIButton *btn = (UIButton*)sender ;
    NSInteger track = [btn tag] ;
    TrackSelection requestTrackSelected = TrackSelectionUndefined ;
    switch (track) {
        case 1:
            requestTrackSelected = TrackSelectionRequire1;
            break;
        case 2:
            requestTrackSelected = TrackSelectionRequire2;
            break;
        case 3:
            requestTrackSelected = TrackSelectionRequire1and2 ;
            break;
        case 4:
            requestTrackSelected = TrackSelectionRequire3 ;
            break;
        case 5:
            requestTrackSelected = TrackSelectionRequire1and3 ;
            break;
        case 6:
            requestTrackSelected = TrackSelectionRequire2and3 ;
            break;
        case 7:
            requestTrackSelected = TrackSelectionRequireAllTracks;
            break;
        case 8:
            requestTrackSelected = TrackSelectionAnyTrack1or2 ;
            break;
        case 9:
            requestTrackSelected = TrackSelectionAnyTrack2or3;
            break;
            
        default:
            break;
    }
    [[Captuvo sharedCaptuvoDevice]setMSRTrackSelection:requestTrackSelected];
}


- (IBAction)firmwareButton:(id)sender {
   [[Captuvo sharedCaptuvoDevice]requestMSRFirmwareVersion];
}

- (IBAction)serialButton:(id)sender {
   [[Captuvo sharedCaptuvoDevice]requestMSRSerialNumber];
}

- (IBAction)enableReading:(id)sender {
   [[Captuvo sharedCaptuvoDevice]enableMSRReader];
}

- (IBAction)disableReading:(id)sender {
   [[Captuvo sharedCaptuvoDevice]disableMSRReader];
}

- (IBAction)trackSettings:(id)sender {
   [[Captuvo sharedCaptuvoDevice]requestMSRTrackSettings];
}

- (IBAction)securityButton:(id)sender {
   [[Captuvo sharedCaptuvoDevice]requestMSRSecurityLevel];
}

- (IBAction)status:(id)sender {
   //[[Captuvo sharedCaptuvoDevice]requestMSRReaderStatus];
}

- (IBAction)passThroughButton:(id)sender {
   const Byte b[]={0x02,0x52,0x4E,0x03,0x1c};
   [[Captuvo sharedCaptuvoDevice]msrPassThrough:[NSData dataWithBytes:&b length:sizeof(b)] expectingReturnData:YES];
   
}


-(void)msrStringDataReceived:(NSString *)data validData:(BOOL)status{
   NSLog(@"MSR Data Received: %@",data);
   NSLog(@"Status: %@", (status?@"YES":@"NO"));
   self.msrData.text = data;
    if (![data containsString:@"MSR HID"]) {
        self.swipesuccessCountlbl.text = [NSString stringWithFormat:@"String Data success count:%ld",(long)swipeSuccessCount++] ;        
    }
}

-(void)msrRawDataReceived:(NSString *)data validData:(BOOL)status{
   NSLog(@"MSR Data Received: %@",data);
   NSLog(@"Status: %@", (status?@"YES":@"NO"));
   self.msrRawData.text = [data description];
}

-(void)msrFirewareVersion:(NSString *)data validData:(BOOL)status{
   NSLog(@"MSR Data Fireware Version: %@",data);
   NSLog(@"Status: %@", (status?@"YES":@"NO"));
   self.msrData.text = data;
}

-(void)msrSerialNumber:(NSString *)data validData:(BOOL)status{
   NSLog(@"MSR Data Serial Number: %@",data);
   NSLog(@"Status: %@", (status?@"YES":@"NO"));
   self.msrData.text = data;
}

-(void)msrCurrentSecurityLevel:(SecurityLevel)securityLevel validData:(BOOL)status{
   self.msrData.text = [NSString stringWithFormat:@"%@ - Vaild Checksum: %@",[MSRTools securityLevelName:securityLevel],(status?@"YES":@"NO") ];
}

-(void)msrPassThroughReturnData:(NSData *)data{
   NSLog(@"MSR Pass Through: %@",data);
   self.msrRawData.text = [data description];
}

-(void)msrCurrentTrackSelection:(TrackSelection)trackSelection validData:(BOOL)status{
   self.msrData.text = [NSString stringWithFormat:@"%@ - Vaild Checksum: %@",[MSRTools trackSelectionName:trackSelection],(status?@"YES":@"NO") ];
}


- (void)msrReady
{
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil
                                                   message:@"22222 msr ready"
                                                  delegate:nil
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
    
    
}

- (void)pmReady{
    
    [[Captuvo sharedCaptuvoDevice] queryMSRHIDMode] ;
    
}

- (void)captuvoConnected{
    
    [[Captuvo sharedCaptuvoDevice] startMSRHardware] ;
    
}

- (IBAction)switchButtonValueChange:(id)sender
{
    UISwitch*switchbtn = (UISwitch*)sender ;
    [[Captuvo sharedCaptuvoDevice] setMSRHID:switchbtn.isOn] ;
}
- (IBAction)queryMSRHIDMode:(id)sender
{
    [[Captuvo sharedCaptuvoDevice] queryMSRHIDMode] ;
}

#pragma mark msrHID mode delegate
- (void)responseMSRHIDMode:(BOOL)isHID
{
    [self.switchbtn setOn:isHID animated:YES] ;
    self.msrHIDModelbl.text = [NSString stringWithFormat:@"MSR HID status:%@",isHID ? @"activate":@"unactive"] ;
}


-(void)captuvoDisconnected{
    
    [[Captuvo sharedCaptuvoDevice] stopMSRHardware] ;
}


@end
