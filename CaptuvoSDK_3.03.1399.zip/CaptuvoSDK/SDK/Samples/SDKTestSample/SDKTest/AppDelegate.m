/*======================================================================
 
 UNLESS OTHERWISE AGREED TO IN A SIGNED WRITING BY HONEYWELL INTERNATIONAL INC
 (“HONEYWELL”) AND THE USER OF THIS CODE, THIS CODE AND INFORMATION IS PROVIDED
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
 FOR A PARTICULAR PURPOSE.
 
 COPYRIGHT (C) 2008 HONEYWELL INTERNATIONAL INC.
 
 THIS SOFTWARE IS PROTECTED BY COPYRIGHT LAWS OF THE UNITED STATES OF
 AMERICA AND OF FOREIGN COUNTRIES. THIS SOFTWARE IS FURNISHED UNDER A
 LICENSE AND/OR A NONDISCLOSURE AGREEMENT AND MAY BE USED IN ACCORDANCE
 WITH THE TERMS OF THOSE AGREEMENTS. UNAUTHORIZED REPRODUCTION,  DUPLICATION
 OR DISTRIBUTION OF THIS SOFTWARE, OR ANY PORTION OF IT  WILL BE PROSECUTED
 TO THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW.
 
 ======================================================================*/
//
//  AppDelegate.m
//  SDKTest
//

#import "AppDelegate.h"

#import "DecoderVC.h"
#import "MSRVC.h"
#import "PMVC.h"
#import "BaseTestVC.h"

@interface AppDelegate()

- (void)redirectNSLogToDocumentFolder;

@end

@implementation AppDelegate

@synthesize window = _window;
//@synthesize viewController = _viewController;
@synthesize tabBarController = _tabBarController;
@synthesize viewController1 = _viewController1 ; 
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [[Captuvo sharedCaptuvoDeviceDebug] addCaptuvoDelegate:self];
    [[Captuvo sharedCaptuvoDevice]enableCaptuvoDebug:YES];

    
//   [self redirectNSLogToDocumentFolder];
   self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
   // Override point for customi/Volumes/CaptuvoSDK/trunk/Source/sdk/Samples/SDK Test Sample/SDKTest.xcodeprojzation after application launch.
    UIViewController *viewController2 = nil  ;
    UIViewController *viewController3 = nil ;
    UIViewController *viewController4 = nil ;
    if (isPad) {
        self.viewController1 = [[BaseTestVC alloc] initWithNibName:@"BaseTestVCiPad" bundle:nil];
        viewController2= [[DecoderVC alloc] initWithNibName:@"DecoderVCiPad" bundle:nil];
        viewController3= [[MSRVC alloc] initWithNibName:@"MSRVCiPad" bundle:nil];
        viewController4= [[PMVC alloc] initWithNibName:@"PMVCiPad" bundle:nil];
    }else{
        self.viewController1 = [[BaseTestVC alloc] initWithNibName:@"BaseTestVC" bundle:nil];
        viewController2= [[DecoderVC alloc] initWithNibName:@"DecoderVC" bundle:nil];
        viewController3= [[MSRVC alloc] initWithNibName:@"MSRVC" bundle:nil];
        viewController4= [[PMVC alloc] initWithNibName:@"PMVC" bundle:nil];
    }
   
   self.tabBarController = [[UITabBarController alloc] init];
   self.tabBarController.viewControllers = [NSArray arrayWithObjects:self.viewController1,viewController2,viewController3,viewController4, nil];
   self.window.rootViewController = self.tabBarController;
   
   [self.window makeKeyAndVisible];
    
    
   return YES;
   
}

- (void)applicationWillResignActive:(UIApplication *)application
{
   // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
   // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
   // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
   // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
   // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
   // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
   // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

-(void)captuvoConnected{

    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil
                                                   message:@"----------Captuvo Connected"
                                                  delegate:self
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{

    [(BaseTestVC*)self.viewController1 viewDidLoad] ;
    
}
-(void)captuvoDisconnected{
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil
                                                   message:@"***********Captuvo Disconnected"
                                                  delegate:nil
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
}

- (void)redirectNSLogToDocumentFolder{
NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
NSString *documentsDirectory = [paths objectAtIndex:0];
NSString *fileName =[NSString stringWithFormat:@"%@.log",[NSDate date]];
NSString *logFilePath = [documentsDirectory stringByAppendingPathComponent:fileName];
freopen([logFilePath cStringUsingEncoding:NSASCIIStringEncoding],"a+",stderr);
}

@end
