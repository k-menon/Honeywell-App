/*======================================================================
 
 UNLESS OTHERWISE AGREED TO IN A SIGNED WRITING BY HONEYWELL INTERNATIONAL INC
 (“HONEYWELL”) AND THE USER OF THIS CODE, THIS CODE AND INFORMATION IS PROVIDED
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
 FOR A PARTICULAR PURPOSE.
 
 COPYRIGHT (C) 2008 HONEYWELL INTERNATIONAL INC.
 
 THIS SOFTWARE IS PROTECTED BY COPYRIGHT LAWS OF THE UNITED STATES OF
 AMERICA AND OF FOREIGN COUNTRIES. THIS SOFTWARE IS FURNISHED UNDER A
 LICENSE AND/OR A NONDISCLOSURE AGREEMENT AND MAY BE USED IN ACCORDANCE
 WITH THE TERMS OF THOSE AGREEMENTS. UNAUTHORIZED REPRODUCTION,  DUPLICATION
 OR DISTRIBUTION OF THIS SOFTWARE, OR ANY PORTION OF IT  WILL BE PROSECUTED
 TO THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW.
 
 ======================================================================*/
//
//  MSRVC.h
//  SDKTest
//

#import <UIKit/UIKit.h>
#import "Captuvo.h"


@interface MSRVC : UIViewController <CaptuvoEventsProtocol>

- (IBAction)startMSR:(id)sender;
- (IBAction)stopMSR:(id)sender;
- (IBAction)allTracksButton:(id)sender;
- (IBAction)track1Button:(id)sender;
- (IBAction)trackcommButton:(id)sender;
- (IBAction)track2Button:(id)sender;
- (IBAction)track3Button:(id)sender;
- (IBAction)firmwareButton:(id)sender;
- (IBAction)serialButton:(id)sender;
- (IBAction)enableReading:(id)sender;
- (IBAction)disableReading:(id)sender;
- (IBAction)trackSettings:(id)sender;
- (IBAction)securityButton:(id)sender;
- (IBAction)status:(id)sender;
- (IBAction)passThroughButton:(id)sender;

- (IBAction)switchButtonValueChange:(id)sender;
- (IBAction)queryMSRHIDMode:(id)sender ;
@property (strong, nonatomic) IBOutlet UILabel *msrData;
@property (strong, nonatomic) IBOutlet UILabel *msrRawData;
@property (strong, nonatomic) IBOutlet UISwitch *switchbtn ; 
@property (strong, nonatomic) IBOutlet UILabel *msrHIDModelbl ;
@property (strong, nonatomic) IBOutlet UILabel *swipesuccessCountlbl ;
@end
