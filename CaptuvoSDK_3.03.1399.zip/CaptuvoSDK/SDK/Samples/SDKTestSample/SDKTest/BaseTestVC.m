/*======================================================================
 
 UNLESS OTHERWISE AGREED TO IN A SIGNED WRITING BY HONEYWELL INTERNATIONAL INC
 (“HONEYWELL”) AND THE USER OF THIS CODE, THIS CODE AND INFORMATION IS PROVIDED
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
 FOR A PARTICULAR PURPOSE.
 
 COPYRIGHT (C) 2008 HONEYWELL INTERNATIONAL INC.
 
 THIS SOFTWARE IS PROTECTED BY COPYRIGHT LAWS OF THE UNITED STATES OF
 AMERICA AND OF FOREIGN COUNTRIES. THIS SOFTWARE IS FURNISHED UNDER A
 LICENSE AND/OR A NONDISCLOSURE AGREEMENT AND MAY BE USED IN ACCORDANCE
 WITH THE TERMS OF THOSE AGREEMENTS. UNAUTHORIZED REPRODUCTION,  DUPLICATION
 OR DISTRIBUTION OF THIS SOFTWARE, OR ANY PORTION OF IT  WILL BE PROSECUTED
 TO THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW.
 
 ======================================================================*/

//
//  BaseTestVC.m
//  SDKTest
//

#import "BaseTestVC.h"

@interface BaseTestVC ()

-(void)throwTestException;

@end

@implementation BaseTestVC
@synthesize nameLabel;
@synthesize manufacturerLabel;
@synthesize modelNumberLabel;
@synthesize serialNumberLabel;
@synthesize firmwareRevLabel;
@synthesize hardwareRevLabel;
@synthesize SDKRevLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
       self.title = @"Base Test";

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //Test shared objects
   Captuvo* c1 = [Captuvo sharedCaptuvoDevice];
   Captuvo* c2 = [Captuvo sharedCaptuvoDevice];
   if(c1 != c2){
      NSLog(@"Shared objects are not the same.");
      [self throwTestException];
   }
   
   
   //Build number test
   NSLog(@"Build Number: %@",[c1 getSDKbuildNumber]);
   
   self.nameLabel.text = [[Captuvo sharedCaptuvoDevice]getCaptuvoName];
   self.manufacturerLabel.text  = [[Captuvo sharedCaptuvoDevice]getCaptuvoManufacturer];
   self.modelNumberLabel.text  = [[Captuvo sharedCaptuvoDevice]getCaptuvoModelNumber];
   self.serialNumberLabel.text  = [[Captuvo sharedCaptuvoDevice]getCaptuvoSerialNumber];
   self.firmwareRevLabel.text  = [[Captuvo sharedCaptuvoDevice]getCaptuvoFirmwareRevision];
   self.hardwareRevLabel.text  = [[Captuvo sharedCaptuvoDevice]getCaptuvoHardwareRevision];
   self.SDKRevLabel.text  = [[Captuvo sharedCaptuvoDevice]getSDKfullVersion];

//   [[Captuvo sharedCaptuvoDevice]startMSRHardware];
//   [[Captuvo sharedCaptuvoDevice]stopMSRHardware];
//   [[Captuvo sharedCaptuvoDevice]startMSRHardware];
//   [[Captuvo sharedCaptuvoDevice]stopMSRHardware];

   //Delege add and remove test
//   [c1 addCaptuvoDelegate:self];
//   NSMutableArray* a1 = [c1 performSelector:@selector(delegateNodeArray)];
//   //   NSMutableArray* a1 = c1.delegateNodeArray;
//   //   NSLog(@"Delegate Array Size: %i",[c1 delegateCount]);
//   NSLog(@"Delegate Array Size: %i",[a1 count]);
//   [c1 addCaptuvoDelegate:self];
//   NSLog(@"Delegate Array Size: %i",[a1 count]);
//   [c1 addCaptuvoDelegate:[[DecoderVC alloc]init]];
//   NSLog(@"Delegate Array Size: %i",[a1 count]);
//   [c1 removeCaptuvoDelegate:self];
//   NSLog(@"Delegate Array Size: %i",[a1 count]);
//   [c1 removeCaptuvoDelegate:self];
//   NSLog(@"Delegate Array Size: %i",[a1 count]);
//   [c1 addCaptuvoDelegate:nil];
//   NSLog(@"Delegate Array Size: %i",[a1 count]);
//   [c1 addCaptuvoDelegate:self];
//   NSLog(@"Delegate Array Size: %i",[a1 count]);
//   if([a1 count] != 1){
//      NSLog(@"Add/Remove delegates faild");
//      [self throwTestException]; 
//   }
}

-(void)throwTestException{
   NSException *exception = [NSException exceptionWithName:@"TestExcpetion"
                                                    reason:@"An exception has been thrown during the test."
                                                  userInfo:nil];
   @throw exception;
}

- (void)viewDidUnload
{
    [self setNameLabel:nil];
    [self setManufacturerLabel:nil];
    [self setModelNumberLabel:nil];
    [self setSerialNumberLabel:nil];
    [self setFirmwareRevLabel:nil];
    [self setHardwareRevLabel:nil];
    [self setSDKRevLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

//-(void)captuvoConnected{
//   NSLog(@"Connected");
//   UIAlertView* sledEventAlert = [[UIAlertView alloc]initWithTitle:nil message:@"Captuvo Connected Event" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//   [sledEventAlert show];
//}
//
//-(void)captuvoDisconnected{
//   NSLog(@"Disconnected");
//   UIAlertView* sledEventAlert = [[UIAlertView alloc]initWithTitle:nil message:@"Captuvo Disconnected Event" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//   [sledEventAlert show];
//}

@end
