/*======================================================================
 
 UNLESS OTHERWISE AGREED TO IN A SIGNED WRITING BY HONEYWELL INTERNATIONAL INC
 (“HONEYWELL”) AND THE USER OF THIS CODE, THIS CODE AND INFORMATION IS PROVIDED
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
 FOR A PARTICULAR PURPOSE.
 
 COPYRIGHT (C) 2008 HONEYWELL INTERNATIONAL INC.
 
 THIS SOFTWARE IS PROTECTED BY COPYRIGHT LAWS OF THE UNITED STATES OF
 AMERICA AND OF FOREIGN COUNTRIES. THIS SOFTWARE IS FURNISHED UNDER A
 LICENSE AND/OR A NONDISCLOSURE AGREEMENT AND MAY BE USED IN ACCORDANCE
 WITH THE TERMS OF THOSE AGREEMENTS. UNAUTHORIZED REPRODUCTION,  DUPLICATION
 OR DISTRIBUTION OF THIS SOFTWARE, OR ANY PORTION OF IT  WILL BE PROSECUTED
 TO THE MAXIMUM EXTENT POSSIBLE UNDER THE LAW.
 
 ======================================================================*///
//  ViewController.m
//  SDKTest
//

#import "DecoderVC.h"
#import "DecoderTools.h"
#include <stdint.h>
#include<mach/mach_time.h>

@interface DecoderVC ()


@end

@implementation DecoderVC
@synthesize scrollView;
@synthesize decoderData;
@synthesize passThrougstring = _passThrougstring ; 
@synthesize start_t = _start_t ;
@synthesize end_t = _end_t ; 

//Raw mach_absolute_times going in,difference in seconds out
uint64_t subtractTimes( uint64_t endTime, uint64_t startTime )
{
    uint64_t difference = endTime - startTime;
    static double conversion = 0.0;
    if( conversion == 0.0 )
    {
        mach_timebase_info_data_t info;
        kern_return_t err =mach_timebase_info( &info );
        //Convert the timebase into seconds
        if( err == 0  )
            conversion= info.numer / info.denom;
    }
    return conversion * difference; //millisecs
    
    
//    uint64_t elapsed = endTime - startTime;
//    
//    mach_timebase_info_data_t info;
//    
//    if (mach_timebase_info (&info) != KERN_SUCCESS)
//        
//    {
//        
//        printf ("mach_timebase_info failed\n");
//        
//    }
//    
//    uint64_t nanosecs = elapsed * info.numer / info.denom;
//    
////    uint64_t millisecs = nanosecs ;
//    
//    return nanosecs ;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Decoder Test";
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.start_t = 0 ;
    self.end_t = 0 ;
    
    self.scrollView.frame=self.view.bounds;
    self.scrollView.center = CGPointMake(self.scrollView.center.x, self.scrollView.center.y + 10 ) ; 
    [self.view addSubview:self.scrollView];
    
    CGFloat version = [[[UIDevice currentDevice] systemVersion] floatValue] ;
    if (isPad) {
        if (version>=7.0) {
            [self.scrollView setContentSize:CGSizeMake(320*2.4, 2.133*3540)];
        }else{
            [self.scrollView setContentSize:CGSizeMake(320*2.4, 2.133*3500)];
        }
    }else{
        if (version>=7.0) {
            [self.scrollView setContentSize:CGSizeMake(320, 4040)];
        }else{
            [self.scrollView setContentSize:CGSizeMake(320, 4000)];
        }
    }
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    
    [self setDecoderData:nil];
    [self setScrollView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[Captuvo sharedCaptuvoDevice] addCaptuvoDelegate:self];
    [[Captuvo sharedCaptuvoDevice] startDecoderHardware] ;
}

-(void)viewDidDisappear:(BOOL)animated
{
     [[Captuvo sharedCaptuvoDevice] removeCaptuvoDelegate:self];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}


- (void)decoderReady
{
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil
                                                   message:@"111111 decoder ready"
                                                  delegate:nil
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
    
    
}

-(void)captuvoConnected{
    
        [[Captuvo sharedCaptuvoDevice] startDecoderHardware] ;
}


-(void)captuvoDisconnected{
    
        [[Captuvo sharedCaptuvoDevice] stopDecoderHardware] ;
}



- (void)getStartTime
{
    self.start_t = 0 ;
    self.end_t = 0 ;
    self.start_t = mach_absolute_time () ;
}

- (void)getEndTime{

    self.end_t = mach_absolute_time() ;
    
    uint64_t elapsed = subtractTimes(self.end_t, self.start_t);
    
    NSString *elapsedtext = [[NSString alloc] initWithFormat:@"start: %f end:%f %f", (double)self.start_t, (double)self.end_t, (double)elapsed/1000000000.0f];
    
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"test sdk performance" message:elapsedtext delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] ;
    [alert show] ;
    
    self.start_t = 0 ;
    self.end_t = 0 ;

}

-(void)decoderDataReceived:(NSString *)data{
    NSLog(@"Decoder Data Received: %@",data);
    
    //[self getEndTime] ;
    
    self.decoderData.text = data;
}
- (void)decoderRawDataReceived:(NSData *)data{
    NSLog(@"- (void)decoderRawDataReceived:(NSData *)data") ;
    NSLog(@"Decoder Binary Data Received: %@",data) ;
    //   self.decoderData.text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ;
}
- (IBAction)enableAimerButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderAimer:NO];
}

- (IBAction)disableAimerButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]disableDecoderAimer:NO];
}

- (IBAction)enableIlluminationButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderIllumination:NO];
        self.decoderData.text = @"llumination is on";
}

- (IBAction)disableIlluminationButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]disableDecoderIllumination:NO];
        self.decoderData.text = @"llumination is off";
}

- (IBAction)startDecoderButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]startDecoderHardware];
}

- (IBAction)stopDecoderButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]stopDecoderHardware];
}

- (IBAction)enableButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderScanning];
}

- (IBAction)disableButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]disableDecoderScanning];
}

- (IBAction)scanOnButton:(id)sender {

    [self getStartTime] ;
    [[Captuvo sharedCaptuvoDevice]startDecoderScanning];
}

- (IBAction)scanOffButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]stopDecoderScanning];
}


- (IBAction)beepOffButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderPowerUpBeep:NO];
}

- (IBAction)beepOnButton:(id)sender {
    [self getStartTime] ;
    [[Captuvo sharedCaptuvoDevice] enableDecoderPowerUpBeep:YES];
}

- (IBAction)clickOnButton:(id)sender {
    [self getStartTime] ;
    [[Captuvo sharedCaptuvoDevice]enableDecoderTriggerClick:YES persistSetting:NO];
}

- (IBAction)clickOffButton:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderTriggerClick:NO persistSetting:NO];
}

- (IBAction)grbvOff:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderGoodReadBeeperVolume:BeeperVolumeOff persistSetting:NO];
}

- (IBAction)grbvLow:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderGoodReadBeeperVolume:BeeperVolumeLow persistSetting:NO];
}
- (IBAction)grbvHigh:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderGoodReadBeeperVolume:BeeperVolumeHigh persistSetting:NO];
}
- (IBAction)grbvMid:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderGoodReadBeeperVolume:BeeperVolumeMedium persistSetting:NO];
}

- (IBAction)grbpHigh:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBeeperPitchGoodRead:BeeperPitchHigh persistSetting:NO];
}

- (IBAction)grbpMid:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBeeperPitchGoodRead:BeeperPitchMedium persistSetting:NO];
}

- (IBAction)grbpLow:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBeeperPitchGoodRead:BeeperPitchLow persistSetting:NO];
}

- (IBAction)erbpHigh:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBeeperPitchError:BeeperErrorPitchHigh persistSetting:NO];
}

- (IBAction)erbpMid:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBeeperPitchError:BeeperErrorPitchMedium persistSetting:NO];
}

- (IBAction)erbpRazz:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBeeperPitchError:BeeperErrorPitchRazz persistSetting:NO];
}

- (IBAction)grbdNormal:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBeeperDurationGoodRead:BeeperDurationNormal persistSetting:NO];
}

- (IBAction)grbdShort:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBeeperDurationGoodRead:BeeperDurationShort persistSetting:NO];
}

- (IBAction)numberBeepsGoodReadAction:(id)sender {
    UISegmentedControl* segmentControl = (UISegmentedControl*)sender;
    switch ([segmentControl selectedSegmentIndex]) {
        case 0:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:1 persistSetting:NO];
            break;
        case 1:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:2 persistSetting:NO];
            break;
        case 2:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:3 persistSetting:NO];
            break;
        case 3:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:4 persistSetting:NO];
            break;
        case 4:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:5 persistSetting:NO];
            break;
        case 5:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:6 persistSetting:NO];
            break;
        case 6:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:7 persistSetting:NO];
            break;
        case 7:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:8 persistSetting:NO];
            break;
        case 8:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsGoodRead:9 persistSetting:NO];
            break;
        default:
            break;
    }
}

- (IBAction)numberBeepsErrorReadAction:(id)sender {
    UISegmentedControl* segmentControl = (UISegmentedControl*)sender;
    switch ([segmentControl selectedSegmentIndex]) {
        case 0:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:1 persistSetting:NO];
            break;
        case 1:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:2 persistSetting:NO];
            break;
        case 2:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:3 persistSetting:NO];
            break;
        case 3:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:4 persistSetting:NO];
            break;
        case 4:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:5 persistSetting:NO];
            break;
        case 5:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:6 persistSetting:NO];
            break;
        case 6:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:7 persistSetting:NO];
            break;
        case 7:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:8 persistSetting:NO];
            break;
        case 8:
            [[Captuvo sharedCaptuvoDevice]setDecoderNumberOfBeepsError:9 persistSetting:NO];
            break;
        default:
            break;
    }
}

- (IBAction)grdOff:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderGoodReadDelayInMilliSeconds:0 persistSetting:NO];
}

- (IBAction)grd1Sec:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderGoodReadDelayInMilliSeconds:1000 persistSetting:NO];
}

- (IBAction)grd5Sec:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderGoodReadDelayInMilliSeconds:5000 persistSetting:NO];
    
}

- (IBAction)grd30Sec:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderGoodReadDelayInMilliSeconds:30000 persistSetting:NO];
}

- (IBAction)tmNormal:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderEnhancedManualTriggerMode:NO persistSetting:NO];
}

- (IBAction)tmEnhanced:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderEnhancedManualTriggerMode:YES persistSetting:NO];
}

- (IBAction)tt1Sec:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderSerialTriggerTimeoutInMilliSeconds:1000 persistSetting:NO];
}
- (IBAction)tt30Sec:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderSerialTriggerTimeoutInMilliSeconds:30000 persistSetting:NO];
}

- (IBAction)tt100Sec:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderSerialTriggerTimeoutInMilliSeconds:100000 persistSetting:NO];
    
}

- (IBAction)tt5Sec:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderSerialTriggerTimeoutInMilliSeconds:5000 persistSetting:NO];
}

- (IBAction)mobileOn:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderOptimizationsForMobilePhoneReading:YES persistSetting:NO];
}

- (IBAction)mobileOff:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderOptimizationsForMobilePhoneReading:NO persistSetting:NO];
}

- (IBAction)rbOn:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderBeeperForGoodRead:YES persistSetting:NO];
}

- (IBAction)rbOff:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderBeeperForGoodRead:NO persistSetting:NO];
}

- (IBAction)psOn:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderPreferredSymbology:YES persistSetting:NO];
}

- (IBAction)psOff:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderPreferredSymbology:NO persistSetting:NO];
}

- (IBAction)psDefault:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderPreferredSymbologyToDefaultPersistSetting:NO];
}

- (IBAction)hpsQR:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderHighPrioritySymbology:SymbologyQRCodeAndMicroQRCode persistSetting:NO];
}

- (IBAction)hpsUPC:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderHighPrioritySymbology:SymbologyUPCA persistSetting:NO];
}

- (IBAction)hpsCode128:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderHighPrioritySymbology:SymbologyCode128 persistSetting:NO];
}

- (IBAction)lpsQR:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderLowPrioritySymbology:SymbologyQRCodeAndMicroQRCode persistSetting:NO];
}

- (IBAction)lpsUPC:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderLowPrioritySymbology:SymbologyUPCA persistSetting:NO];
}



- (IBAction)lpsCode128:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderLowPrioritySymbology:SymbologyCode128 persistSetting:NO];
}

- (IBAction)pst500MS:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderPreferredSymbologyTimeoutInMilliSeconds:500 persistSetting:NO];
}

- (IBAction)pst1s:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderPreferredSymbologyTimeoutInMilliSeconds:1000 persistSetting:NO];
}

- (IBAction)pst2s:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderPreferredSymbologyTimeoutInMilliSeconds:2000 persistSetting:NO];
}

- (IBAction)pst3s:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderPreferredSymbologyTimeoutInMilliSeconds:3000 persistSetting:NO];
}

- (IBAction)rbStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderBeeperForGoodReadStatus];
}

- (IBAction)tcStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderTriggerClickStatus];
}

- (IBAction)pbStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderPowerUpBeepStatus];
}

- (IBAction)grbvStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderGoodReadBeeperVolumeStatus];
}

- (IBAction)grbpStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderBeeperPitchGoodReadStatus];
}

- (IBAction)erbpStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderBeeperPitchErrorStatus];
}

- (IBAction)grbdStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderBeeperDurationGoodReadStatus];
}

- (IBAction)snobgrStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderNumberOfBeepsGoodReadStatus];
}

- (IBAction)snoberStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderNumberOfBeepsErrorStatus];
}

- (IBAction)grdStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderGoodReadDelayInMilliSecondsStatus];
}


- (IBAction)ttoStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderSerialTriggerTimeoutInMilliSecondsStatus];
}

- (IBAction)amStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderInterlacedAimerModeStatus];
}

- (IBAction)psStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice] requestDecoderPreferredSymbologyStatus];
}

- (IBAction)hpsStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice] requestDecoderHighPrioritySymbologyStatus];
}

- (IBAction)lpsStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice] requestDecoderLowPrioritySymbologyStatus];
}

- (IBAction)pstStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice] requestDecoderPreferredSymbologyTimeoutInMilliSecondsStatus];
}

- (IBAction)cOn:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderCentering:YES persistSetting:NO];
}

- (IBAction)cOff:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderCentering:NO persistSetting:NO];
}

- (IBAction)cStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderCenteringStatus];
}

- (IBAction)ct10:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderTopOfCenteringWindow:10 persistSetting:NO];
}

- (IBAction)ct25:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderTopOfCenteringWindow:25 persistSetting:NO];
}

- (IBAction)ct40:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderTopOfCenteringWindow:40 persistSetting:NO];
}

- (IBAction)ctStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderTopOfCenteringWindowStatus];
}

- (IBAction)cb10:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBottomOfCenteringWindow:10 persistSetting:NO];
}

- (IBAction)cb25:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBottomOfCenteringWindow:25 persistSetting:NO];
}

- (IBAction)upcaOff:(id)sender {
    UPCA* upca = [[UPCA alloc]init];
    upca.enabled=NO;
    upca.enableCheckDigit = NO ;
    upca.enable2DigitAddenda = NO ;
    upca.enable5DigitAddenda = NO ;
    upca.enableNumberSystem = NO ; 
    [[Captuvo sharedCaptuvoDevice] setDecoderUPCAConfiguration:upca persistSetting:NO];
}

- (IBAction)upcaOn:(id)sender {
    UPCA* upca = [[UPCA alloc]init];
    upca.enabled=YES;
    upca.enableCheckDigit = YES ;
    upca.enable2DigitAddenda = YES ;
    upca.enable5DigitAddenda = YES ;
    upca.enableNumberSystem = YES ; 
    [[Captuvo sharedCaptuvoDevice]setDecoderUPCAConfiguration:upca persistSetting:NO];
}

- (IBAction)ean13On:(id)sender {
    EAN13* ean13 = [[EAN13 alloc]init];
    ean13.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderEAN13Configuration:ean13 persistSetting:NO];
}

- (IBAction)ean13Off:(id)sender {
    EAN13* ean13 = [[EAN13 alloc]init];
    ean13.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderEAN13Configuration:ean13 persistSetting:NO];
}

- (IBAction)upce0On:(id)sender {
    UPCE0* upce0 = [[UPCE0 alloc]init];
    upce0.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderUPCE0Configuration:upce0 persistSetting:NO];
}

- (IBAction)upce0Off:(id)sender {
    UPCE0* upce0 = [[UPCE0 alloc]init];
    upce0.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderUPCE0Configuration:upce0 persistSetting:NO];
}

- (IBAction)ean8On:(id)sender {
    EAN8* ean8 = [[EAN8 alloc]init];
    ean8.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderEAN8Configuration:ean8 persistSetting:NO];
}

- (IBAction)allOn:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableAllSymbologiesPersistSetting:NO];
}

- (IBAction)allOff:(id)sender {
    [[Captuvo sharedCaptuvoDevice]disableAllSymbologiesPersistSetting:NO];
}

- (IBAction)codabarOn:(id)sender {
    Codabar* cb = [[Codabar alloc]init];
    cb.enabled=YES;
    cb.maxMessageLength=99;
    cb.minMessageLength=0;
    [[Captuvo sharedCaptuvoDevice]setDecoderCodabarConfiguration:cb persistSetting:NO];
}

- (IBAction)codabarOff:(id)sender {
    Codabar* cb = [[Codabar alloc]init];
    cb.enabled=NO;
    cb.maxMessageLength=33;
    cb.minMessageLength=22;
    [[Captuvo sharedCaptuvoDevice]setDecoderCodabarConfiguration:cb persistSetting:NO];
}

- (IBAction)ean8Off:(id)sender {
    EAN8* ean8 = [[EAN8 alloc]init];
    ean8.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderEAN8Configuration:ean8 persistSetting:NO];
}

- (IBAction)code39Off:(id)sender {
    Code39* code39 = [[Code39 alloc]init];
    code39.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderCode39Configuration:code39 persistSetting:NO];
}

- (IBAction)code39On:(id)sender {
    Code39* code39 = [[Code39 alloc]init];
    code39.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderCode39Configuration:code39 persistSetting:NO];
}

- (IBAction)interleaved2of5On:(id)sender {
    Interleaved2of5* i25 = [[Interleaved2of5 alloc]init];
    i25.enabled = YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderInterleaved2of5Configuration:i25 persistSetting:NO];
}

- (IBAction)interleaved2of5Off:(id)sender {
    Interleaved2of5* i25 = [[Interleaved2of5 alloc]init];
    i25.enabled = NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderInterleaved2of5Configuration:i25 persistSetting:NO];
}

- (IBAction)nec2of5On:(id)sender {
    NEC2of5* n25 = [[NEC2of5 alloc]init];
    n25.enabled = YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderNEC2of5Configuration:n25 persistSetting:NO];
}

- (IBAction)nec2of5Off:(id)sender {
    NEC2of5* n25 = [[NEC2of5 alloc]init];
    n25.enabled = NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderNEC2of5Configuration:n25 persistSetting:NO];
}

- (IBAction)code93On:(id)sender {
    Code93* code93 = [[Code93 alloc]init];
    code93.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderCode93Configuration:code93 persistSetting:NO];
}

- (IBAction)code93Off:(id)sender {
    Code93* code93 = [[Code93 alloc]init];
    code93.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderCode93Configuration:code93 persistSetting:NO];
}

- (IBAction)straight2of5On:(id)sender {
    Straight2of5Industrial* s25 = [[Straight2of5Industrial alloc]init];
    s25.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderStraight2of5IndustrialConfiguration:s25 persistSetting:NO];
}

- (IBAction)straight2of5Off:(id)sender {
    Straight2of5Industrial* s25 = [[Straight2of5Industrial alloc]init];
    s25.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderStraight2of5IndustrialConfiguration:s25 persistSetting:NO];
}

- (IBAction)straight2of5IATAon:(id)sender {
    Straight2of5IATA* s25 = [[Straight2of5IATA alloc]init];
    s25.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderStraight2of5IATAConfiguration:s25 persistSetting:NO];
}

- (IBAction)straight2of5IATAoff:(id)sender {
    Straight2of5IATA* s25 = [[Straight2of5IATA alloc]init];
    s25.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderStraight2of5IATAConfiguration:s25 persistSetting:NO];
}

- (IBAction)matrix2of5On:(id)sender {
    Matrix2of5* m25 = [[Matrix2of5 alloc]init];
    m25.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderMatrix2of5Configuration:m25 persistSetting:NO];
}

- (IBAction)matrix2of5Off:(id)sender {
    Matrix2of5* m25 = [[Matrix2of5 alloc]init];
    m25.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderMatrix2of5Configuration:m25 persistSetting:NO];
}

- (IBAction)code11On:(id)sender {
    Code11* c11 = [[Code11 alloc]init];
    c11.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderCode11Configuration:c11 persistSetting:NO];
}

- (IBAction)code11Off:(id)sender {
    Code11* c11 = [[Code11 alloc]init];
    c11.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderCode11Configuration:c11 persistSetting:NO];
}

- (IBAction)code128On:(id)sender {
    Code128* c128 = [[Code128 alloc]init];
    c128.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderCode128Configuration:c128 persistSetting:NO];
}

- (IBAction)code128Off:(id)sender {
    Code128* c128 = [[Code128 alloc]init];
    c128.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderCode128Configuration:c128 persistSetting:NO];
}

- (IBAction)gs1On:(id)sender {
    GS1_128* gs1 = [[GS1_128 alloc]init];
    gs1.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderGS1_128Configuration:gs1 persistSetting:NO];
}

- (IBAction)gs1Off:(id)sender {
    GS1_128* gs1 = [[GS1_128 alloc]init];
    gs1.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderGS1_128Configuration:gs1 persistSetting:NO];
}

- (IBAction)telepenOn:(id)sender {
    Telepen* telepen = [[Telepen alloc]init];
    telepen.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderTelepenConfiguration:telepen persistSetting:NO];
}

- (IBAction)telepenOff:(id)sender {
    Telepen* telepen = [[Telepen alloc]init];
    telepen.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderTelepenConfiguration:telepen persistSetting:NO];
}

- (IBAction)msiOn:(id)sender {
    MSI* msi = [[MSI alloc] init];
    msi.enabled=YES;
    msi.minMessageLength = 4 ;
    msi.maxMessageLength = 40 ;
    msi.checkChar = MSICheckCharDisableCeckChar ;
    [[Captuvo sharedCaptuvoDevice]setDecoderMSIConfiguration:msi persistSetting:NO];
}

- (IBAction)msiOff:(id)sender {
    MSI* msi = [[MSI alloc]init];
    msi.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderMSIConfiguration:msi persistSetting:NO];
}

- (IBAction)gs1BDomniOn:(id)sender {
    GS1DataBarOmnidirectional* gs1 = [[GS1DataBarOmnidirectional alloc]init];
    gs1.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderGS1DataBarOmnidirectionalConfiguration:gs1 persistSetting:NO];
}

- (IBAction)gs1BDomniOff:(id)sender {
    GS1DataBarOmnidirectional* gs1 = [[GS1DataBarOmnidirectional alloc]init];
    gs1.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderGS1DataBarOmnidirectionalConfiguration:gs1 persistSetting:NO];
}

- (IBAction)gs1BDlimitOn:(id)sender {
    GS1DataBarLimited* gs1 = [[GS1DataBarLimited alloc]init];
    gs1.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderGS1DataBarLimitedConfiguration:gs1 persistSetting:NO];
}

- (IBAction)gs1BDlimitOff:(id)sender {
    GS1DataBarLimited* gs1 = [[GS1DataBarLimited alloc]init];
    gs1.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderGS1DataBarLimitedConfiguration:gs1 persistSetting:NO];
}

- (IBAction)gs1BDexpandedOn:(id)sender {
    GS1DataBarExpanded* gs1 = [[GS1DataBarExpanded alloc]init];
    gs1.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderGS1DataBarExpandedConfiguration:gs1 persistSetting:NO];
}

- (IBAction)gs1BDexpandedOff:(id)sender {
    GS1DataBarExpanded* gs1 = [[GS1DataBarExpanded alloc]init];
    gs1.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderGS1DataBarExpandedConfiguration:gs1 persistSetting:NO];
}

- (IBAction)codablockAOn:(id)sender {
    CodablockA* codablockA = [[CodablockA alloc]init];
    codablockA.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderCodablockAConfiguration:codablockA persistSetting:NO];
}

- (IBAction)codablockAOff:(id)sender {
    CodablockA* codablockA = [[CodablockA alloc]init];
    codablockA.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderCodablockAConfiguration:codablockA persistSetting:NO];
}

- (IBAction)codablockFOn:(id)sender {
    CodablockF* codablockF = [[CodablockF alloc]init];
    codablockF.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderCodablockFConfiguration:codablockF persistSetting:NO];
}

- (IBAction)codablockFOff:(id)sender {
    CodablockF* codablockF = [[CodablockF alloc]init];
    codablockF.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderCodablockFConfiguration:codablockF persistSetting:NO];
}

- (IBAction)pdf417On:(id)sender {
    PDF417* pdf417 = [[PDF417 alloc]init];
    pdf417.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderPDF417Configuration:pdf417 persistSetting:NO];
}

- (IBAction)pdf417Off:(id)sender {
    PDF417* pdf417 = [[PDF417 alloc]init];
    pdf417.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderPDF417Configuration:pdf417 persistSetting:NO];
}

- (IBAction)dataMatrixOn:(id)sender {
    DataMatrix* dm = [[DataMatrix alloc]init];
    dm.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderDataMatrixConfiguration:dm persistSetting:NO];
}

- (IBAction)dataMatrixOff:(id)sender {
    DataMatrix* dm = [[DataMatrix alloc]init];
    dm.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderDataMatrixConfiguration:dm persistSetting:NO];
}

- (IBAction)maxiCodeOn:(id)sender {
    MaxiCode* mc = [[MaxiCode alloc]init];
    mc.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderMaxiCodeConfiguration:mc persistSetting:NO];
}

- (IBAction)maxiCodeOff:(id)sender {
    MaxiCode* mc = [[MaxiCode alloc]init];
    mc.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderMaxiCodeConfiguration:mc persistSetting:NO];
}

- (IBAction)aztecOn:(id)sender {
    Aztec* aztec = [[Aztec alloc]init];
    aztec.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderAztecConfiguration:aztec persistSetting:NO];
}

- (IBAction)aztecOff:(id)sender {
    Aztec* aztec = [[Aztec alloc]init];
    aztec.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderAztecConfiguration:aztec persistSetting:NO];
}

- (IBAction)chineseSensibleOn:(id)sender {
    ChineseSensible* cs = [[ChineseSensible alloc]init];
    cs.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderChineseSensibleConfiguration:cs persistSetting:NO];
}

- (IBAction)chineseSensibleOff:(id)sender {
    ChineseSensible* cs = [[ChineseSensible alloc]init];
    cs.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderChineseSensibleConfiguration:cs persistSetting:NO];
}

- (IBAction)qrCodeOn:(id)sender {
    QRCode* qrc = [[QRCode alloc]init];
    qrc.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderQRCodeConfiguration:qrc persistSetting:NO];
}

- (IBAction)qrCodeOff:(id)sender {
    QRCode* qrc = [[QRCode alloc]init];
    qrc.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderQRCodeConfiguration:qrc persistSetting:NO];
}

- (IBAction)tcifOn:(id)sender {
    TCIFLinkedCode39* tcif = [[TCIFLinkedCode39 alloc]init];
    tcif.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderTCIFLinkedCode39Configuration:tcif persistSetting:NO];
}

- (IBAction)tcifOff:(id)sender {
    TCIFLinkedCode39* tcif = [[TCIFLinkedCode39 alloc]init];
    tcif.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderTCIFLinkedCode39Configuration:tcif persistSetting:NO];
}

- (IBAction)mpdfOn:(id)sender {
    MicroPDF417* mpdf = [[MicroPDF417 alloc]init];
    mpdf.enabled=YES;
    [[Captuvo sharedCaptuvoDevice]setDecoderMicroPDF417Configuration:mpdf persistSetting:NO];
}

- (IBAction)mpdfOff:(id)sender {
    MicroPDF417* mpdf = [[MicroPDF417 alloc]init];
    mpdf.enabled=NO;
    [[Captuvo sharedCaptuvoDevice]setDecoderMicroPDF417Configuration:mpdf persistSetting:NO];
}

- (IBAction)amOff:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderInterlacedAimerMode:NO persistSetting:NO];
}

- (IBAction)amOn:(id)sender {
    [[Captuvo sharedCaptuvoDevice]enableDecoderInterlacedAimerMode:YES persistSetting:NO];
}

- (IBAction)passThough:(id)sender {
//    const Byte msg[]={0x16,0x4d,0x0d,0x52,0x45,0x56,0x49,0x4e,0x46,0x2e};
//    NSData* msgData = [NSMutableData dataWithBytes:&msg length:sizeof(msg)];
//    [[Captuvo sharedCaptuvoDevice]decoderPassThrough:msgData expectingReturnData:YES];
    self.passThrougstring = nil;
    
//    const Byte msg[]={0x16,0x4d,0x0d,'R','E','V','_','W','A',0x3f,0x2e};
    const Byte msg[]={0x16,0x4d,0x0d,'R','E','V','_','W','A',0x3f,';','R','E','V','_','W','A',0x3f,'.'};//'D','E','F','A','L','T','.'};//,0x2e,';'
    
    NSData* msgData = [NSMutableData dataWithBytes:&msg length:sizeof(msg)];
    [[Captuvo sharedCaptuvoDevice]decoderPassThrough:msgData expectingReturnData:YES];
    
}

- (IBAction)cb40:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderBottomOfCenteringWindow:40 persistSetting:NO];
}

- (IBAction)cbStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderBottomOfCenteringWindowStatus];
}

- (IBAction)cl10:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderLeftOfCenteringWindow:10 persistSetting:NO];
}

- (IBAction)cl25:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderLeftOfCenteringWindow:25 persistSetting:NO];
}

- (IBAction)cl40:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderLeftOfCenteringWindow:40 persistSetting:NO];
}

- (IBAction)clStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderLeftOfCenteringWindowStatus];
}

- (IBAction)cr10:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderRightOfCenteringWindow:10 persistSetting:NO];
}

- (IBAction)cr25:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderRightOfCenteringWindow:25 persistSetting:NO];
}

- (IBAction)cr40:(id)sender {
    [[Captuvo sharedCaptuvoDevice]setDecoderRightOfCenteringWindow:40 persistSetting:NO];
}

- (IBAction)crStatus:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderRightOfCenteringWindowStatus];
}

- (IBAction)decoderRevision:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderRevision];
}

- (IBAction)driverRevision:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderDriverRevision];
}

- (IBAction)softwareRevision:(id)sender {
    [[Captuvo sharedCaptuvoDevice]requestDecoderSoftwareRevision];
}

- (IBAction)obtainEngineSN:(id)sender
{
    
    [[Captuvo sharedCaptuvoDevice] requestEngineSerialNumber];
}

-(void)EngineSerialNumber:(NSString*)seralNumber
{
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:nil
                                                   message:seralNumber
                                                  delegate:nil
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
    

    
      self.decoderData.text = seralNumber;
}

-(void)decoderPassThroughReturnData:(NSData *)data{
    if (self.passThrougstring!=nil) {
        self.passThrougstring = [NSString stringWithFormat:@"%@-%@",self.passThrougstring,[[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding] ] ;
    }else{
        self.passThrougstring = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding] ;
    }
    
    
    self.decoderData.text = self.passThrougstring;
    
}

-(void)decoderBeeperForGoodReadStatus:(BOOL)isOn{
    self.decoderData.text = (isOn ? @"Good Read Beeper On" : @"Good Read Beeper Off");
}

-(void)decoderTriggerClickStatus:(BOOL)isOn{
    [self getEndTime] ;
    self.decoderData.text = (isOn ? @"Trigger Click On" : @"Trigger Click Off");
}

-(void)decoderPowerUpBeepStatus:(BOOL)isOn{
    [self getEndTime];
    self.decoderData.text = (isOn ? @"Power Up Beep On" : @"Power Up Beep Off");
}

-(void)decoderGoodReadBeeperVolumeStatus:(BeeperVolume)volume{
    switch (volume) {
        case BeeperVolumeHigh:
            self.decoderData.text = @"Good Read Beeper Volume High";
            break;
        case BeeperVolumeMedium:
            self.decoderData.text = @"Good Read Beeper Volume Medium";
            break;
        case BeeperVolumeLow:
            self.decoderData.text = @"Good Read Beeper Volume Low";
            break;
        case BeeperVolumeOff:
            self.decoderData.text = @"Good Read Beeper Volume Off";
            break;
        default:
            self.decoderData.text = @"Good Read Beeper Volume ERROR";
            break;
    }
}
-(void)decoderBeeperPitchGoodReadStatus:(BeeperPitch)pitch{
    switch (pitch) {
        case BeeperPitchHigh:
            self.decoderData.text = @"Good Read Beeper Pitch High";
            break;
        case BeeperPitchMedium:
            self.decoderData.text = @"Good Read Beeper Pitch Medium";
            break;
        case BeeperPitchLow:
            self.decoderData.text = @"Good Read Beeper Pitch Low";
            break;
        default:
            self.decoderData.text = @"Good Read Beeper Pitch ERROR";
            break;
    }
}

-(void)DecoderEnhancedManualTriggerMode:(NSData*)data
{
    
    NSString *status_str = nil;
    
    status_str = [NSString stringWithFormat:@" Trigger Mode return value is :%@",data] ;
    
    self.decoderData.text = status_str;
}

-(void)decoderBeeperPitchErrorStatus:(BeeperErrorPitch)pitch{
    switch (pitch) {
        case BeeperErrorPitchHigh:
            self.decoderData.text = @"Error Beeper Pitch High";
            break;
        case BeeperErrorPitchMedium:
            self.decoderData.text = @"Error Beeper Pitch Medium";
            break;
        case BeeperErrorPitchRazz:
            self.decoderData.text = @"Error Beeper Pitch Razz";
            break;
        default:
            self.decoderData.text = @"Error Beeper Pitch ERROR";
            break;
    }
}
-(void)decoderBeeperDurationGoodReadStatus:(BeeperDuration)duration{
    switch (duration) {
        case BeeperDurationNormal:
            self.decoderData.text = @"Good Read Beeper Duration Normal";
            break;
        case BeeperDurationShort:
            self.decoderData.text = @"Good Read Beeper Duration Short";
            break;
        default:
            break;
    }
}

-(void)decoderNumberOfBeepsGoodReadStatus:(int)numberOfBeeps{
    self.decoderData.text = [NSString stringWithFormat:@"Number of Beeps Good Read: %i",numberOfBeeps];
}

-(void)decoderNumberOfBeepsErrorStatus:(int)numberOfBeeps{
    self.decoderData.text = [NSString stringWithFormat:@"Number of Beeps Error Read: %i",numberOfBeeps];
}

-(void)decoderGoodReadDelayInMilliSecondsStatus:(int)milliseconds{
    self.decoderData.text = [NSString stringWithFormat:@"Good Read Delay in Milliseconds: %i",milliseconds];
}

-(void)decoderSerialTriggerTimeoutInMilliSecondsStatus:(int)milliseconds{
    self.decoderData.text = [NSString stringWithFormat:@"Serial Timeout in Milliseconds: %i",milliseconds];
}

-(void)decoderInterlacedAimerModeStatus:(BOOL)isEnabled{
    self.decoderData.text = (isEnabled ? @"Interlaced Aimer On" : @"Interlaced Aimer Off");
}

-(void)decoderPreferredSymbologyStatus:(BOOL)isEnabled{
    self.decoderData.text = (isEnabled ? @"Preferred Symbology On" : @"Preferred Symbology Off");
    
}

-(void)decoderPreferredSymbologyTimeoutInMilliSecondsStatus:(int)milliseconds{
    self.decoderData.text = [NSString stringWithFormat:@"Preferred Symbology Delay in Milliseconds: %i",milliseconds];
}

-(void)decoderHighPrioritySymbologyStatus:(Symbology)symbology{
    self.decoderData.text = [NSString stringWithFormat:@"High Priority Symbology: %@",[DecoderTools symbologyName:symbology]];
}

-(void)decoderLowPrioritySymbologyStatus:(Symbology)symbology{
    self.decoderData.text = [NSString stringWithFormat:@"Low Priority Symbology: %@",[DecoderTools symbologyName:symbology]];
}

-(void)decoderCenteringStatus:(BOOL)isEnabled{
    self.decoderData.text = (isEnabled ? @"Centering On" : @"Centering Off");
}

-(void)decoderTopOfCenteringWindowLocation:(int)locationAsPrecent{
    self.decoderData.text = [NSString stringWithFormat:@"Top of centering window location: %i",locationAsPrecent];
}

-(void)decoderBottomOfCenteringWindowLocation:(int)locationAsPrecent{
    self.decoderData.text = [NSString stringWithFormat:@"Bottom of centering window location: %i",locationAsPrecent];
}

-(void)decoderLeftOfCenteringWindowLocation:(int)locationAsPrecent{
    self.decoderData.text = [NSString stringWithFormat:@"Left of centering window location: %i",locationAsPrecent];
}

-(void)decoderRightOfCenteringWindowLocation:(int)locationAsPrecent{
    self.decoderData.text = [NSString stringWithFormat:@"Right of centering window location: %i",locationAsPrecent];
}

-(void)decoderDriverRevision:(NSString *)revision{

    
//    if (self.passThrougstring!=nil) {
//        self.passThrougstring = [NSString stringWithFormat:@"%@-%@",self.passThrougstring,revision] ;
//    }else{
    
       // self.passThrougstring = revision ;
  //  }

    
    self.decoderData.text = revision;
}

-(void)decoderSoftwareRevision:(NSString *)revision{
//    self.decoderData.text = revision;
//    if (self.passThrougstring!=nil) {
//        self.passThrougstring = [NSString stringWithFormat:@"%@-%@",self.passThrougstring,revision] ;
//    }else{
//        self.passThrougstring = revision ;
//    }
//    
    
    self.decoderData.text = revision;
    
}

-(void)decoderRevisionReceived:(NSString *)revision{
//    self.decoderData.text = revision;
//    if (self.passThrougstring!=nil) {
//        self.passThrougstring = [NSString stringWithFormat:@"%@-%@",self.passThrougstring,revision] ;
//    }else{
//        self.passThrougstring = revision ;
//    }
//    
    
    self.decoderData.text = revision;
    
}


@end
